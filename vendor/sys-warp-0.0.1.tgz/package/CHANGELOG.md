# Changelog — @sys/warp

## Unreleased

- Add **environment-integrity** builder (`crossServiceEnvTargetCheck`) + pure `evaluateEnvironment` and the `environment-topology` / `IdentityRegistry` contract. Asserts the cross-service env-target invariant: for any environment, every service on the request/auth/data path resolves to the same environment family. Unknown identities **fail closed** (no family inferred). Extracted from the Qarar staging→prod-API 401 incident (the canary).

## 0.0.1

Initial extraction from Qarar (2026-06-03). Config cross-validation harness. Generic check runner + reusable check builders; usable as a library or the `sys-warp` CLI.
